
<?php $__env->startSection('title', env('APP_NAME') . ' | Artist View'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="card">
                <div class="card-title">
                    <h4>View Artist</h4>
                    <?php if(Session::has('msg')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="basic-form">



                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Artist Name</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" placeholder="full name" name="name"
                                        value="<?php echo e($artist->name); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label>Username</label><span class="text-info">(This field is not changable)</span>
                                    <span class="form-control"><?php echo e($artist->username); ?></span>
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label><span class="text-info">(This field is not changable)</span>
                                    <span class="form-control"><?php echo e($artist->email); ?></span>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label>Phone</label>
                                    <input disabled type="text" class="form-control" id="phone" placeholder="phone number"
                                        name="phone" value="<?php echo e($artist->phone); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Main Address</label>
                            <input disabled type="text" class="form-control" placeholder="address" name="address"
                                value="<?php echo e($artist->address); ?>" id="autocomplete">
                            <input disabled type="hidden" name="latitude" id="latitude" value="<?php echo e(@$artist->latitude); ?>">
                            <input disabled type="hidden" name="longitude" id="longitude" value="<?php echo e(@$artist->longitude); ?>">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label>Address Line 2</label>
                            <input disabled type="text" class="form-control"
                                placeholder="Enter additional address details like premises, apartment no etc."
                                name="address2" value="<?php echo e($artist->address2); ?>">
                            <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Country</label><span class="text-danger">*</span>
                                    
                                    <select disabled class="form-control" id="country" name="country">
                                        <?php $__currentLoopData = config('contry.countries'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>State</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="state" placeholder="state"
                                        name="state" value="<?php echo e($artist->state); ?>">
                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>City</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="city" placeholder="city"
                                        name="city" value="<?php echo e($artist->city); ?>">
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Zip Code</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="zipcode" placeholder="zipcode"
                                        name="zipcode" value="<?php echo e($artist->zipcode); ?>">
                                    <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Hourly Rate</label><span class="text-danger">*</span>
                                    <input disabled type="number" class="form-control" id="hourly_rate"
                                        placeholder="Hourly Rate" name="hourly_rate"
                                        value="<?php echo e(@$artistData->hourly_rate); ?>">
                                    <?php $__errorArgs = ['hourly_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Speciality</label><span class="text-danger">*</span>
                                    <select disabled name="specialty" class="form-control" value="<?php echo e(old('specialty')); ?>">
                                        <option value="">select style</option>
                                        <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($style->id); ?>"
                                                <?php echo e(@$artistData->specialty == $style->id ? 'selected' : ''); ?>>
                                                <?php echo e($style->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['specialty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Years In Trade</label><span class="text-danger">*</span>
                                    <input disabled type="number" class="form-control" id="years_in_trade"
                                        placeholder="Years In Trade" name="years_in_trade"
                                        value="<?php echo e(@$artistData->years_in_trade); ?>">
                                    <?php $__errorArgs = ['years_in_trade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Walk in Welcome</label>
                                    <select disabled name="walk_in_welcome" class="form-control">
                                        <option disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->walk_in_welcome == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->walk_in_welcome == 'no' ? 'selected' : ''); ?>>
                                            No</option>
                                    </select>
                                    <?php $__errorArgs = ['walk_in_welcome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Certified Professionals</label><span class="text-danger">*</span>
                                    <select disabled name="certified_professionals" class="form-control"
                                        value="<?php echo e(old('certified_professionals')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->certified_professionals == 'yes' ? 'selected' : ''); ?>>Yes
                                        </option>
                                        <option value="no"
                                            <?php echo e(@$artistData->certified_professionals == 'no' ? 'selected' : ''); ?>>No
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['certified_professionals'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Consultations Available</label>
                                    <select disabled name="consultation_available" class="form-control"
                                        value="<?php echo e(old('consultation_available')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->consultation_available == 'yes' ? 'selected' : ''); ?>>Yes
                                        </option>
                                        <option value="no"
                                            <?php echo e(@$artistData->consultation_available == 'no' ? 'selected' : ''); ?>>No
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['consultation_available'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Language Spoken</label><span class="text-danger">*</span>
                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="English" id="English"
                                            <?php echo e(in_array('English', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="English">
                                            English
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="Spanish" id="Spanish"
                                            <?php echo e(in_array('Spanish', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Spanish">
                                            Spanish
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="French" id="French"
                                            <?php echo e(in_array('French', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="French">
                                            French
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="Italian" id="Italian"
                                            <?php echo e(in_array('Italian', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Italian">
                                            Italian
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="Chinese" id="Chinese"
                                            <?php echo e(in_array('Chinese', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Chinese">
                                            Chinese
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="Farsi" id="Farsi"
                                            <?php echo e(in_array('Farsi', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Farsi">
                                            Farsi
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="language_spoken[]"
                                            value="Other" id="Other"
                                            <?php echo e(in_array('Other', @$languageSpoken) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Other">
                                            Other
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['language_spoken'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Parking Available</label>
                                    <select disabled name="parking" class="form-control" value="<?php echo e(old('parking')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes" <?php echo e(@$artistData->parking == 'yes' ? 'selected' : ''); ?>>Yes
                                        </option>
                                        <option value="no" <?php echo e(@$artistData->parking == 'no' ? 'selected' : ''); ?>>No
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['parking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Payment Option</label><span class="text-danger">*</span>
                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="Cash" id="Cash"
                                            <?php echo e(in_array('Cash', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Cash">
                                            Cash
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="Check" id="Check"
                                            <?php echo e(in_array('Check', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Check">
                                            Check
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="CC" id="CC"
                                            <?php echo e(in_array('CC', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="CC">
                                            CC
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="Venomo" id="Venomo"
                                            <?php echo e(in_array('Venomo', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Venomo">
                                            Venmo
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="Zelle" id="Zelle"
                                            <?php echo e(in_array('Zelle', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Zelle">
                                            Zelle
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="CashApp" id="CashApp"
                                            <?php echo e(in_array('CashApp', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="CashApp">
                                            CashApp
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="Paypal" id="Paypal"
                                            <?php echo e(in_array('Paypal', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="Paypal">
                                            Paypal
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="ApplePay" id="ApplePay"
                                            <?php echo e(in_array('ApplePay', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="ApplePay">
                                            ApplePay
                                        </label>
                                    </div>

                                    <div class="form-check">
                                        <input disabled class="form-check-input" type="checkbox" name="payment_method[]"
                                            value="GooglePay" id="GooglePay"
                                            <?php echo e(in_array('GooglePay', @$PaymentMethod) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="GooglePay">
                                            GooglePay
                                        </label>
                                    </div>

                                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Air Conditioned</label>
                                    <select disabled name="air_conditioned" class="form-control"
                                        value="<?php echo e(old('air_conditioned')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->air_conditioned == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->air_conditioned == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['air_conditioned'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Water Available</label><span class="text-danger">*</span>
                                    <select disabled name="water_available" class="form-control"
                                        value="<?php echo e(old('certified_professionals')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->water_available == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->water_available == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['water_available'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Coffee Available</label>
                                    <select disabled name="coffee_available" class="form-control"
                                        value="<?php echo e(old('coffee_available')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->coffee_available == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->coffee_available == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['coffee_available'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Masks Worn</label><span class="text-danger">*</span>
                                    <select disabled name="mask_worn" class="form-control" value="<?php echo e(old('mask_worn')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes" <?php echo e(@$artistData->mask_worn == 'yes' ? 'selected' : ''); ?>>
                                            Yes</option>
                                        <option value="no" <?php echo e(@$artistData->mask_worn == 'no' ? 'selected' : ''); ?>>No
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['mask_worn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Vaccinated Staff</label>
                                    <select disabled name="vaccinated_staff" class="form-control"
                                        value="<?php echo e(old('vaccinated_staff')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->vaccinated_staff == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->vaccinated_staff == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['vaccinated_staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Wheel Chair Accessible</label><span class="text-danger">*</span>
                                    <select disabled name="wheel_chair_accessible" class="form-control"
                                        value="<?php echo e(old('mask_worn')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->wheel_chair_accessible == 'yes' ? 'selected' : ''); ?>>Yes
                                        </option>
                                        <option value="no"
                                            <?php echo e(@$artistData->wheel_chair_accessible == 'no' ? 'selected' : ''); ?>>No
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['wheel_chair_accessible'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Bike Parking</label>
                                    <select disabled name="bike_parking" class="form-control" value="<?php echo e(old('bike_parking')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->bike_parking == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no" <?php echo e(@$artistData->bike_parking == 'no' ? 'selected' : ''); ?>>
                                            No</option>
                                    </select>
                                    <?php $__errorArgs = ['bike_parking'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Wifi Available</label><span class="text-danger">*</span>
                                    <select disabled name="wifi_available" class="form-control"
                                        value="<?php echo e(old('wifi_available')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->wifi_available == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->wifi_available == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['wifi_available'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Artist of The Year</label>
                                    <select disabled name="artist_of_the_year" class="form-control"
                                        value="<?php echo e(old('artist_of_the_year')); ?>">
                                        <option selected disabled>select option</option>
                                        <option value="yes"
                                            <?php echo e(@$artistData->artist_of_the_year == 'yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="no"
                                            <?php echo e(@$artistData->artist_of_the_year == 'no' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['artist_of_the_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Instagram Account</label><span class="text-danger">*</span>
                                    <input disabled type="url" class="form-control" id="insta_handle"
                                        placeholder="Instagram Account" name="insta_handle"
                                        value="<?php echo e(@$artistData->insta_handle); ?>">
                                    <?php $__errorArgs = ['insta_handle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook Account</label><span class="text-danger">*</span>
                                    <input disabled type="url" class="form-control" id="facebook_handle"
                                        placeholder="facebook_handle" name="facebook_handle"
                                        value="<?php echo e(@$artistData->facebook_handle); ?>">
                                    <?php $__errorArgs = ['facebook_handle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>YouTube Account</label><span class="text-danger">*</span>
                                    <input disabled type="url" class="form-control" id="youtube_handle"
                                        placeholder="YouTube Account" name="youtube_handle"
                                        value="<?php echo e(@$artistData->youtube_handle); ?>">
                                    <?php $__errorArgs = ['youtube_handle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>X - Twitter</label><span class="text-danger">*</span>
                                    <input disabled type="url" class="form-control" id="twitter_handle"
                                        placeholder="X - Twitter" name="twitter_handle"
                                        value="<?php echo e(@$artistData->twitter_handle); ?>">
                                    <?php $__errorArgs = ['twitter_handle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Google Map API</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="google_map_api"
                                        placeholder="Google Map API" name="google_map_api"
                                        value="<?php echo e(@$artistData->google_map_api); ?>">
                                    <?php $__errorArgs = ['google_map_api'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Yelp API</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="yelp_api" placeholder="Yelp API"
                                        name="yelp_api" value="<?php echo e(@$artistData->yelp_api); ?>">
                                    <?php $__errorArgs = ['yelp_api'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Shop Percentage</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="shop_percentage"
                                        placeholder="Shop Percentage" name="shop_percentage"
                                        value="<?php echo e(@$artistData->shop_percentage); ?>">
                                    <?php $__errorArgs = ['shop_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>
                        
                        <div class="row">

                            <div class="col-md-6" id="companyLogo">
                                <div class="form-group">
                                    <label>Current Shop Logo</label>
                                    
                                    <?php if(
                                        !empty($artist->artistData->shop_logo) &&
                                            Storage::disk('public')->exists('ShopImage/' . $artist->artistData->shop_logo)): ?>
                                        <img style="height: 82px; width: 82px;"
                                            src="<?php echo e(asset('storage/ShopImage/' . $artist->artistData->shop_logo)); ?>"
                                            alt="">
                                    <?php else: ?>
                                        <img style="height: 82px; width: 82px;" src="<?php echo e(asset('noimg.png')); ?>"
                                            alt="">
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo e(@$artist->created_by == 0 ? 'Admin' : 'Sales Person'); ?> Email</label><span
                                        class="text-danger">*</span>
                                    <input disabled type="email" class="form-control"
                                        value="<?php echo e(@$artist->created_by == 0 ? 'admin@mail.com' : @$artist->createdBy->email); ?>"
                                        readonly>
                                    <?php $__errorArgs = ['shop_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Shop Email</label><span class="text-danger">*</span>
                                    <input disabled type="email" class="form-control" id="shop_email" placeholder="Shop Email"
                                        name="shop_email" value="<?php echo e(@$artistData->shop_email); ?>"
                                        pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$">
                                    <?php $__errorArgs = ['shop_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Shop Name</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="shop_name" placeholder="Shop Name"
                                        name="shop_name" value="<?php echo e(@$artistData->shop_name); ?>">
                                    <?php $__errorArgs = ['shop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Shop Address</label><span class="text-danger">*</span>
                                    <input disabled type="text" class="form-control" id="shop_address"
                                        placeholder="Shop Address" name="shop_address"
                                        value="<?php echo e(@$artistData->shop_address); ?>">
                                    <?php $__errorArgs = ['shop_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>



                        

                        

                        <div class="row">

                            <div class="col-md-6" id="companyLogo">
                                <div class="form-group">
                                    <label>Current Profile Image</label>
                                    <?php if(!empty($artist->profile_image) && Storage::disk('public')->exists('ProfileImage/' . $artist->profile_image)): ?>
                                        <img style="height: 82px; width: 82px;"
                                            src="<?php echo e(asset('storage/ProfileImage/' . $artist->profile_image)); ?>"
                                            alt="">
                                    <?php else: ?>
                                        <img style="height: 82px; width: 82px;" src="<?php echo e(asset('noimg.png')); ?>"
                                            alt="">
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Current Banner Image</label>
                                    <?php if(!empty($artist->banner_image) && Storage::disk('public')->exists('BannerImage/' . $artist->banner_image)): ?>
                                        <img style="height: 82px; width: 82px;"
                                            src="<?php echo e(asset('storage/BannerImage/' . $artist->banner_image)); ?>"
                                            alt="">
                                    <?php else: ?>
                                        <img style="height: 82px; width: 82px;" src="<?php echo e(asset('noimg.png')); ?>"
                                            alt="">
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">

                                </div>
                            </div>
                        </div>



                        <div class="row" id="profileHours">

                            <div class="col-md-1">
                                <label>Sunday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="sunday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->sunday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="sunday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->sunday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="sunday_close" id="check1"
                                    <?php echo e(@$artist->timeData->sunday_from == '00:00' && @$artist->timeData->sunday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>
                            </div>


                            <div class="col-md-1">
                                <label>Monday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="monday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->monday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="monday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->monday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="monday_close" id="check2"
                                    <?php echo e(@$artist->timeData->monday_from == '00:00' && @$artist->timeData->monday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>

                            </div>

                            <div class="col-md-1">
                                <label>Tuesday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="tuesday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->tuesday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="tuesday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->tuesday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="tuesday_close" id="check3"
                                    <?php echo e(@$artist->timeData->tuesday_from == '00:00' && @$artist->timeData->tuesday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>

                            </div>
                            <div class="col-md-1">
                                <label>Wednesday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="wednesday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->wednesday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="wednesday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->wednesday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="wednesday_close" id="check5"
                                    <?php echo e(@$artist->timeData->wednesday_from == '00:00' && @$artist->timeData->wednesday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>

                            </div>

                            <div class="col-md-1">
                                <label>Thrusday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="thrusday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->thrusday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="thrusday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->thrusday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="thrusday_close" id="check6"
                                    <?php echo e(@$artist->timeData->thrusday_from == '00:00' && @$artist->timeData->thrusday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>

                            </div>

                            <div class="col-md-1">
                                <label>Friday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="friday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->friday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="friday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->friday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="friday_close" id="check7"
                                    <?php echo e(@$artist->timeData->friday_from == '00:00' && @$artist->timeData->friday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>

                            </div>

                            <div class="col-md-1">
                                <label>Saterday Time</label>
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="saterday_from"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->saterday_from))); ?>"
                                    class="form-control">
                            </div>

                            <div class="col-md-2">
                                <input disabled type="time" name="saterday_to"
                                    value="<?php echo e(date('H:i', strtotime(@$artist->timeData->saterday_to))); ?>"
                                    class="form-control">

                            </div>
                            <div class="col-md-1">
                                <input disabled type="checkbox" name="saterday_close" id="check8"
                                    <?php echo e(@$artist->timeData->saterday_from == '00:00' && @$artist->timeData->saterday_to == '00:00' ? 'checked' : ''); ?>>
                                <label class="form-check-label">Close</label>

                            </div>

                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <!-- Include Inputmask from CDN -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
        <script async
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAE6dk-Oc544R2gZpwVqPQDhN0VGAjkxhw&loading=async&libraries=places&callback=initAutocomplete">
        </script>

        <script>
            // Function to initialize the autocomplete
            function initAutocomplete() {
                // Create the autocomplete object, restricting the search to the US
                var input = $('#autocomplete')[0];
                var options = {
                    types: ['address'],
                    componentRestrictions: {
                        country: 'us'
                    }
                };
                var autocomplete = new google.maps.places.Autocomplete(input, options);

                // Event listener for when a place is selected
                autocomplete.addListener('place_changed', function() {
                    var place = autocomplete.getPlace();
                    if (!place.geometry) {
                        console.log("No details available for input: '" + place.name + "'");
                        return;
                    }

                    // Extracting address components
                    var addressComponents = place.address_components;
                    var country = '';
                    var state = '';
                    var city = '';
                    var zipCode = '';

                    // Loop through each component to find country, state, city, and zip code
                    $.each(addressComponents, function(index, component) {
                        var componentType = component.types[0];
                        if (componentType === 'country') {
                            country = component.long_name;
                        } else if (componentType === 'administrative_area_level_1') {
                            state = component.long_name;
                        } else if (componentType === 'locality') {
                            city = component.long_name;
                        } else if (componentType === 'postal_code') {
                            zipCode = component.long_name;
                        }
                    });

                    // Extract latitude and longitude
                    var latitude = place.geometry.location.lat();
                    var longitude = place.geometry.location.lng();

                    if (country.length > 0) {
                        $("#country").val(country);
                    }

                    if (state.length > 0) {
                        $("#state").val(state);
                    }

                    if (city.length > 0) {
                        $("#city").val(city);
                    }

                    if (zipCode.length > 0) {
                        $("#zipcode").val(zipCode);
                    }

                    $("#latitude").val(latitude);
                    $("#longitude").val(longitude);
                    $("#shop_address").val($("#autocomplete").val());
                    // Display the extracted address components
                    console.log('Country:', country);
                    console.log('State:', state);
                    console.log('City:', city);
                    console.log('Zip Code:', zipCode);
                    console.log('Latitude:', latitude);
                    console.log('Longitude:', longitude);
                });
            }

            $(document).ready(function() {
                $('#phone').inputmask('(999) 999-9999');

                $("#submitProfileUpdate").on("click", function() {
                    $("#phone").inputmask({
                        removeMaskOnSubmit: true
                    });
                    $("#artistProfileUpdate").submit();
                });

                $("#autocomplete").on("change", function() {
                    $("#shop_address").val($(this).val());
                });

                $("#hourly_rate").on("input", function() {
                    var value = $(this).val();
                    if (value.length > 3) {
                        $(this).val(value.slice(0, 3));
                    }
                });

                $("#years_in_trade").on("input", function() {
                    var value = $(this).val();
                    if (value.length > 2) {
                        $(this).val(value.slice(0, 2));
                    }
                });

            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tatoo-artist\resources\views/admin/artist/show.blade.php ENDPATH**/ ?>
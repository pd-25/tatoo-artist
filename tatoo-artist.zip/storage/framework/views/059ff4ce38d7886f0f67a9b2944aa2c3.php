
<?php $__env->startSection('title', env('APP_NAME') . ' | Artist-index'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">

        <div class="col-lg-10">
            <div class="card">
                <div class="card-title text-right">
                    <a href="<?php echo e(route('admin.addCustomer')); ?>" class="btn btn-sm btn-success">Add Customer</a>

                </div>
                <div class="card-title pr">
                    <h4>All Customers</h4>
                    <?php if(Session::has('msg')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
                    <?php endif; ?>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table student-data-table m-t-20">
                            <form action="<?php echo e(route('admin.customers')); ?>" method="get">
                                <div class="row">
                                    <div class="col-md-10">
                                        <input type="text" class="form-control" name="search_customer"
                                            id="artwrk_tbl_filter" placeholder="Search data for this page">
                                    </div>
                                    <div class="col-md-2">
                                        <Button type="submit" class="btn btn-md btn-success">Search</Button>
                                    </div>
                                </div>
                            </form>

                            <thead>
                                <tr>
                                    <th>SN.</th>
                                    <th>Full name</th>
                                    <th>Username</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <?php if(Auth::guard('artists')->check()): ?>
                                    <th>Address</th>
                                    <?php else: ?>
                                    <th>Created By</th>
                                    
                                    <?php endif; ?>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#</td>
                                        <td>
                                            <?php echo e($customer->name); ?>

                                        </td>

                                        <td>
                                            <?php echo e($customer->username); ?>

                                        </td>

                                        <td>
                                            <?php echo e($customer->phone); ?>

                                        </td>

                                        <td>
                                            <?php echo e($customer->email); ?>

                                        </td>
                                        <?php if(Auth::guard('artists')->check()): ?>
                                        <td>
                                            <?php echo e(isset($customer->address) ? $customer->address : 'Not Provided!'); ?>


                                        </td>
                                        <?php else: ?>
                                        <td>
                                            <?php echo e(isset($customer->creator_name) ? $customer->creator_name : 'Added By You'); ?>


                                        </td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(route('admin.editCustomer', $customer->id)); ?>"><i
                                                    class="ti-pencil btn btn-sm btn-primary"></i></a>
                                            <form method="POST"
                                                action="<?php echo e(route('admin.destroyCustomer', $customer->id)); ?>"
                                                class="action-icon">
                                                <?php echo csrf_field(); ?>
                                                <input name="_method" type="hidden" value="DELETE">
                                                <button type="submit"
                                                    class="btn btn-sm btn-danger  delete-icon show_confirm"
                                                    data-toggle="tooltip" title='Delete'>
                                                    <i class="ti-trash"></i>
                                                </button>
                                            </form>
                                        </td>

                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#artwork_tbl').filterTable('#artwrk_tbl_filter');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tatoo-artist\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', env('APP_NAME').' | Artist-index'  ); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">

        <div class="col-lg-10">
            <div class="card">
                <div class="card-title pr">
                    <h4>All Payments</h4>
                    <?php if(Session::has('msg')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-title text-right">
                    <a href="<?php echo e(route('admin.AddpaymentForm')); ?>" class="btn btn-sm btn-success">Add Payment</a>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table student-data-table m-t-20">
                            <thead>
                                <tr>

                                    <th>Date</th>
                                    <th>Customer Name</th>
                                    <th>Design</th>
                                    <th>Placement</th>
                                    <th>Price</th>
                                    <th>Deposit</th>
                                    <th>Tips</th>
                                    <th>Fees</th>
                                    <th>Total Due</th>
                                    <th>Payment Method</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($payments)>0): ?>
                                  <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td>
                                            <?php echo e($payment->date); ?>

                                        </td>
                                        <td>
                                            <?php echo e($payment->customers_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($payment->design); ?>

                                        </td>
                                        <td> <?php echo e($payment->placementData->title); ?></td>
                                        <td>
                                            <?php echo e($payment->price); ?>

                                        </td>
                                        <td>
                                            <?php echo e($payment->deposit); ?>

                                        </td>
                                        <td>
                                            <?php echo e($payment->tips); ?>

                                        </td>
                                        <td>
                                            <?php echo e($payment->fees); ?>

                                        </td>
                                        <td>
                                            <?php echo e($payment->total_due); ?>

                                        </td>

                                        <td>
                                            <?php if($payment->payment_method == 'atm_debit'): ?>
                                            Atm/Debit
                                            <?php elseif($payment->payment_method == 'cash'): ?>
                                            Cash
                                            <?php elseif($payment->payment_method == 'credit_card'): ?>
                                            Credit Card
                                            <?php else: ?>
                                            Gift Card
                                            <?php endif; ?>
                                        </td>
                                        <td>

                                            <a href="<?php echo e(route('admin.editpaymentForm', encrypt($payment->id))); ?>"><i
                                                    class="ti-pencil btn btn-sm btn-primary"></i></a>
                                            <form method="POST"
                                                action="<?php echo e(route('admin.deletepaymentForm', encrypt($payment->id))); ?>"
                                                class="action-icon">
                                                <?php echo csrf_field(); ?>
                                                <input name="_method" type="hidden" value="DELETE">
                                                <button type="submit"
                                                    class="btn btn-sm btn-danger  delete-icon show_confirm"
                                                    data-toggle="tooltip" title='Delete'>
                                                    <i class="ti-trash"></i>
                                                </button>
                                            </form>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>
                                    <tr>
                                        <td colspan="12" style="text-align: center;">
                                            <b>No record is found at this moment!</b>
                                        </td>
                                    </tr>    
                                <?php endif; ?>   
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function changeStatus(slug, id) {
            $.ajax({
                type: "POST",
                url: "#",
                data: {
                    'service_slug': slug,
                    '_token': '<?php echo e(csrf_token()); ?>'
                },
                dataType: "JSON",
                success: function(response) {
                    if (response.status) {
                        $("#status-btn"+ id).load(window.location.href + " #status-btn"+ id);
                        swal('Status updated');
                    }else {
                        swal('Some Error occur, relode the page');
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tatoo-artist\resources\views/admin/payment/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', env('APP_NAME').' | Artist-index'  ); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">

        <div class="col-lg-10">
            <div class="card">
                <div class="card-title pr">
                    <h4>All Expenses </h4>
                    <?php if(Session::has('msg')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-title text-right">
                    <a href="<?php echo e(route('admin.AddexpensesForm')); ?>" class="btn btn-sm btn-success">Add Expenses</a>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table student-data-table m-t-20">
                            <thead>
                                <tr>
                                    <th>SL No</th>
                                    <th>Artist</th>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Amount</th>
                                    <th>Expenses</th>
                                    <th>Transaaction Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($expense)>0): ?>
                                    <?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index+1); ?></td>
                                            <td>
                                                <?php echo e($expenses->user->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e(date('jS F, Y', strtotime($expenses->created_at))); ?>

                                            </td>
                                            <td>
                                                <?php echo e(ucfirst($expenses->payment_method)); ?>

                                            </td>
                                            <td>
                                                $<?php echo e($expenses->amount); ?>

                                            </td>
                                            <td><?php echo e(ucfirst($expenses->expense_items)); ?></td>
                                            <td>
                                                <?php echo e(date('jS F, Y', strtotime($expenses->transaction_date))); ?>

                                            </td>
                                            <td>

                                                <a href="<?php echo e(route('admin.editexpensesForm', encrypt($expenses->id))); ?>"><i
                                                        class="ti-pencil btn btn-sm btn-primary"></i></a>
                                                <form method="POST"
                                                    action="<?php echo e(route('admin.deleteexpensesForm', encrypt($expenses->id))); ?>"
                                                    class="action-icon">
                                                    <?php echo csrf_field(); ?>
                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <button type="submit"
                                                        class="btn btn-sm btn-danger  delete-icon show_confirm"
                                                        data-toggle="tooltip" title='Delete'>
                                                        <i class="ti-trash"></i>
                                                    </button>
                                                </form>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" style="text-align: center;">
                                            <b>No record is found at this moment!</b>
                                        </td>
                                    </tr>    
                                <?php endif; ?>    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function changeStatus(slug, id) {
            $.ajax({
                type: "POST",
                url: "#",
                data: {
                    'service_slug': slug,
                    '_token': '<?php echo e(csrf_token()); ?>'
                },
                dataType: "JSON",
                success: function(response) {
                    if (response.status) {
                        $("#status-btn"+ id).load(window.location.href + " #status-btn"+ id);
                        swal('Status updated');
                    }else {
                        swal('Some Error occur, relode the page');
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tatoo-artist\resources\views/admin/expense/index.blade.php ENDPATH**/ ?>
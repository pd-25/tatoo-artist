
<?php $__env->startSection('title', env('APP_NAME').' | Artist-index'  ); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">

        <div class="col-lg-10">
            <div class="card">
                <div class="card-title pr">
                    <h4>All Artists ( <?php echo e($totalArtists); ?> )</h4>
                    <?php if(Session::has('msg')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-title text-right">
                    <a href="<?php echo e(route('artists.create')); ?>" class="btn btn-sm btn-success">Add Artist</a>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table student-data-table m-t-20">
                           <?php if(auth()->guard('admins')->check()): ?>
                           <form action="<?php echo e(route('artists.index')); ?>" method="get">
                            <div class="row">
                                <div class="col-md-10">
                                    <input type="text" class="form-control" name="search_customer"
                                        id="artwrk_tbl_filter" placeholder="Search data for this page">
                                </div>
                                <div class="col-md-2">
                                    <Button type="submit" class="btn btn-md btn-primary">Search</Button>
                                </div>
                            </div>
                        </form>
                           <?php endif; ?>
                            <thead>
                                <tr>
                                    <th>SN.</th>
                                    <th>Full name</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Profile Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($artists)>0): ?>
                                    <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <tr>
                                            <td><?php echo e($index+1); ?></td>
                                            <td>
                                                <?php echo e($artist->name); ?>

                                                
                                            </td>
                                            <td>
                                                <?php echo e($artist->username); ?>

                                                
                                            </td>
                                            <td>
                                                <?php echo e($artist->email); ?>

                                                
                                            </td>
                                            <td>
                                                <?php if(!empty($artist->profile_image) && File::exists(public_path('storage/ProfileImage/' . $artist->profile_image))): ?>
                                                <img style="height: 82px; width: 82px;" src="<?php echo e(asset('storage/ProfileImage/'.$artist->profile_image)); ?>" alt="">
                                                    
                                                <?php else: ?>
                                                <img style="height: 82px; width: 82px;" src="<?php echo e(asset('noimg.png')); ?>" alt="">
                                                    
                                                <?php endif; ?>
                                                
                                                
                                            </td>
                                            
                                            
                                            <td>
                                                <a href="<?php echo e(route('artists.show', encrypt($artist->id))); ?>"><i
                                                    class="ti-eye btn btn-sm btn-success"></i></a>
                                                <a href="<?php echo e(route('artists.edit', encrypt($artist->id))); ?>"><i
                                                        class="ti-pencil btn btn-sm btn-primary"></i></a>
                                                        <a href="<?php echo e(route('admin.impersonateartist', $artist->id)); ?>">        
                                                            <i class="ti-power-off btn btn-sm btn-info"></i>
                                                        </a>  
                                                <form method="POST"
                                                    action="<?php echo e(route('artists.destroy', encrypt($artist->id))); ?>"
                                                    class="action-icon">
                                                    <?php echo csrf_field(); ?>
                                                    <input name="_method" type="hidden" value="DELETE">
                                                    <button type="submit"
                                                        class="btn btn-sm btn-danger  delete-icon show_confirm"
                                                        data-toggle="tooltip" title='Delete'>
                                                        <i class="ti-trash"></i>
                                                    </button>
                                                </form>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" style="text-align: center;">
                                            <b>No record is found at this moment!</b>
                                        </td>
                                    </tr>    
                                <?php endif; ?>        
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function changeStatus(slug, id) {
            $.ajax({
                type: "POST",
                url: "#",
                data: {
                    'service_slug': slug,
                    '_token': '<?php echo e(csrf_token()); ?>'
                },
                dataType: "JSON",
                success: function(response) {
                    if (response.status) {
                        $("#status-btn"+ id).load(window.location.href + " #status-btn"+ id);
                        swal('Status updated');
                    }else {
                        swal('Some Error occur, relode the page');
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tatoo-artist\resources\views/admin/artist/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', env('APP_NAME') . ' | Category-edit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="card">
                <div class="card-title">
                    <h4>Edit Payment</h4>
                    <?php if(Session::has('message')): ?>
                        <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="basic-form">
                        <form action="<?php echo e(route('admin.editpaymentPost', encrypt($payments->id))); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Artist</label><span class="text-danger">*</span>
                                        <?php if(Auth::guard('artists')->check()): ?>
                                            <input type="text" class="form-control" placeholder="Artist Name" name="artist_name" value="<?php echo e($payments->artist->name); ?>" readonly>
                                            <input type="hidden" name="artist_id" value="<?php echo e(Auth::guard('artists')->user()->id); ?>">
                                        <?php else: ?>
                                            <select name="artist_id" class="form-control" value="<?php echo e(old('artist_id')); ?>">
                                                <option value="">select artist</option>
                                                <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($payments->artist_id == $artist->id ? 'selected' : ''); ?>

                                                        value="<?php echo e($artist->id); ?>"><?php echo e($artist->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['artist_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Design</label><span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Design" name="design" value="<?php echo e($payments->design); ?>" required>
                                        <?php $__errorArgs = ['design'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Price</label>
                                        <input type="text" class="form-control" placeholder="Price" name="price" value="<?php echo e($payments->price); ?>">
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Tips</label>
                                        <input type="text" class="form-control" placeholder="Tips" name="tips" value="<?php echo e($payments->tips); ?>">
                                        <?php $__errorArgs = ['tips'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Total Due</label>
                                        <input type="text" class="form-control" placeholder="Total Due" name="total_due" value="<?php echo e($payments->total_due); ?>">
                                        <?php $__errorArgs = ['total_due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Deposit Slip</label>
                                        <input type="file" class="form-control" name="bill_image">
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="hidden" name="old_image_path" value="<?php echo e($payments->bill_image); ?>">
                                            <?php if(!empty($payments->bill_image)): ?>
                                                <img style="height: 82px; width: 82px;"
                                                    src="<?php echo e(asset($payments->bill_image)); ?>"
                                                    alt="">
                                            <?php else: ?>
                                                <img style="height: 82px; width: 82px;" src="<?php echo e(asset('noimg.png')); ?>"
                                                    alt="">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Customers Name</label><span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Customers Name" name="customers_name" value="<?php echo e($payments->customers_name); ?>" required>
                                        <?php $__errorArgs = ['customers_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Placement</label>
                                        <select name="placement" class="form-control" value="<?php echo e(old('placement')); ?>">
                                            <option value="">select placement</option>
                                            <?php $__currentLoopData = $placements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($payments->placement == $placement->id ? 'selected' : ''); ?>

                                                    value="<?php echo e($placement->id); ?>"><?php echo e($placement->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['placement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Deposit</label>
                                        <input type="text" class="form-control" placeholder="Deposit" name="deposit" value="<?php echo e($payments->deposit); ?>">
                                        <?php $__errorArgs = ['deposit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Fees</label>
                                        <input type="text" class="form-control" placeholder="Fees" name="fees" value="<?php echo e($payments->fees); ?>">
                                        <?php $__errorArgs = ['fees'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Payment Method</label>
                                        <select name="payment_method" class="form-control">
                                            <option value="atm_debit" <?php if($payments->payment_method == 'atm_debit'): ?> selected <?php endif; ?>>Atm/Debit</option>
                                            <option value="cash" <?php if($payments->payment_method == 'cash'): ?> selected <?php endif; ?>>Cash</option>
                                            <option value="credit_card" <?php if($payments->payment_method == 'credit_card'): ?> selected <?php endif; ?>>Credit Card</option>
                                            <option value="gift_card" <?php if($payments->payment_method == 'gift_card'): ?> selected <?php endif; ?>>Gift Card</option>
                                        </select>
                                        <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-default">Submit</button>
                            <button type="button" class="btn btn-primary" onclick="window.print()">Print</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // You can add any additional JavaScript here if needed
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tatoo-artist\resources\views/admin/payment/edit.blade.php ENDPATH**/ ?>
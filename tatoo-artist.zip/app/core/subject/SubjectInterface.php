<?php
namespace App\core\subject;

interface SubjectInterface {
    public function getAllSubjects();
}


<?php
namespace App\core\placement;

interface PlacementInterface {
    public function getAllPlacements();
}


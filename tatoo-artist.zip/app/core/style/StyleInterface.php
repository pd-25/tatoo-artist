<?php
namespace App\core\style;

interface StyleInterface {
    public function getAllStyle();
}

